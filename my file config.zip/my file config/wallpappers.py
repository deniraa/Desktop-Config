#!/usr/bin/python
##
#Sets your background to random image from directory using feh
##
import os
import random
import subprocess

IMAGE_DIRECTORY = "/home/irma/Wallpapers/"
IMAGE_FORMATS = ['jpg', 'png']

ALL_IMAGES = []

def getAllImages ():
    root = os.listdir(IMAGE_DIRECTORY)
    for myFile in root:
        isImage = False
        for myFormat in IMAGE_FORMATS:
            if(myFile[-3:] == myFormat):
                isImage = True
            if (isImage):
                path = IMAGE_DIRECTORY + myFile
                ALL_IMAGES.append(path)
                isImage = False
                break

def selectImage ():
    imageCount = len(ALL_IMAGES)
    return ALL_IMAGES[random.randint(0, imageCount-1)]
 
getAllImages()
selectedImage = selectImage()
subprocess.call(('feh', '--bg-fill', selectedImage))