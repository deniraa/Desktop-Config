import __MY_MODULE__

class __MY_CLASS__:

    def __init__(self):
        pass

if __name__ == '__main__':
    pass
